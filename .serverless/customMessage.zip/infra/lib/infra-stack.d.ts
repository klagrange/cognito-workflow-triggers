import * as cdk from '@aws-cdk/core';
export declare class InfraStack extends cdk.Stack {
    constructor(scope: cdk.App, id: string, props?: cdk.StackProps);
}
